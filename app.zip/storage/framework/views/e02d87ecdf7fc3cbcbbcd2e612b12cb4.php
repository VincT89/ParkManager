<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">Monitoraggio Sistema</div>
            <div class="pm-page-subtitle">Rilevamento anomalie e gestione overbooking</div>
        </div>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>

    <?php if(count($alerts) === 0): ?>
        <div class="pm-card pm-animate pm-alert-empty-state">
            <div class="pm-alert-empty-icon">
                <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <div>
                <div class="pm-alert-message">
                    Nessuna emergenza attiva
                </div>
                <div class="pm-alert-suggestion">
                    Tutti i canali operano senza anomalie e con capacità sicura.
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="pm-gap">

            
            <div class="pm-stats-grid pm-animate">
                <div class="pm-stat" style="border-top-color: var(--pm-accent)">
                    <div class="pm-stat-label">Alert in corso</div>
                    <div class="pm-stat-value amber"><?php echo e(count($alerts)); ?></div>
                    <div class="pm-stat-delta">Segnalazioni complessive</div>
                </div>
                <div class="pm-stat" style="border-top-color: var(--pm-red)">
                    <div class="pm-stat-label">Stato Critico</div>
                    <div class="pm-stat-value red">
                        <?php echo e(count(array_filter($alerts, fn($a) => $a['level'] === 'danger'))); ?>

                    </div>
                    <div class="pm-stat-delta" style="color:var(--pm-red)">Richiede intervento</div>
                </div>
                <div class="pm-stat" style="border-top-color: var(--pm-amber)">
                    <div class="pm-stat-label">Attenzione</div>
                    <div class="pm-stat-value amber">
                        <?php echo e(count(array_filter($alerts, fn($a) => $a['level'] === 'warning'))); ?>

                    </div>
                    <div class="pm-stat-delta">Avvertimenti di capienza</div>
                </div>
                <div class="pm-stat" style="border-top-color: var(--pm-blue)">
                    <div class="pm-stat-label">Canali a rischio</div>
                    <div class="pm-stat-value blue">
                        <?php echo e(count(array_unique(array_column($alerts, 'platform')))); ?>

                    </div>
                    <div class="pm-stat-delta">su <?php echo e(\App\Models\Platform::where('is_active', true)->count()); ?> piattaforme</div>
                </div>
            </div>

            
            <div class="pm-card pm-animate-2">
                <div class="pm-card-header" style="border-bottom: 1px solid var(--pm-border); padding-bottom: 16px; margin-bottom: 20px;">
                    <div class="pm-card-title">Interventi Richiesti</div>
                    <div class="pm-card-badge">Monitoraggio live: <?php echo e(now()->isoFormat('HH:mm')); ?></div>
                </div>

                <div class="pm-gap">
                    <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="pm-alert-row <?php echo e($alert['level']); ?>">
                            <div class="pm-alert-icon-wrap <?php echo e($alert['level']); ?>">
                                <?php if($alert['level'] === 'danger'): ?>
                                    <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                    </svg>
                                <?php else: ?>
                                    <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                <?php endif; ?>
                            </div>

                            <div style="flex:1">
                                <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px">
                                    <span class="pm-alert-badge <?php echo e($alert['level']); ?>">
                                        <?php echo e($alert['platform']); ?>

                                    </span>
                                    <span class="pm-alert-context">
                                        • &nbsp; <?php echo e($alert['level'] === 'danger' ? 'Azione Immediata' : 'Allerta Preventiva'); ?>

                                    </span>
                                </div>
                                <div class="pm-alert-message <?php echo e($alert['level']); ?>">
                                    <?php echo e($alert['message']); ?>

                                </div>
                                <div class="pm-alert-suggestion">
                                    <strong>Suggerimento:</strong> <?php echo e($alert['suggestion']); ?>

                                </div>
                            </div>

                            <div style="display:flex; align-items:center; align-self: center; margin-left:16px; gap:8px;">
                                <form action="<?php echo e(route('alerts.dismiss', $alert['id'])); ?>" method="POST" style="margin: 0;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="pm-btn pm-btn-ghost" style="color: var(--pm-text-muted); font-size: 12px; padding: 6px 12px; height: auto;">
                                        Ignora
                                    </button>
                                </form>
                                <a href="<?php echo e($alert['link']); ?>" class="pm-btn pm-alert-action-btn <?php echo e($alert['level']); ?>">
                                    <?php echo e($alert['action_text'] ?? 'Risolvi'); ?>

                                    <svg width="16" height="16" style="margin-left: 6px;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                      <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <div class="pm-card pm-animate-3">
                <div class="pm-card-header">
                    <div class="pm-card-title">Parametri di Allerta Globali</div>
                    <div class="pm-card-badge">Configurazione Attiva</div>
                </div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:16px">
                    <div class="pm-param-card">
                        <div class="pm-stat-label">Allerta Capacità</div>
                        <div class="pm-param-value" style="color:var(--pm-amber)">
                            <?php echo e(\App\Services\AlertService::OCCUPANCY_WARNING_PCT); ?>%
                        </div>
                        <div class="pm-param-desc">
                            Scatta l'avviso preventivo per potenziale esaurimento posti.
                        </div>
                    </div>
                    <div class="pm-param-card">
                        <div class="pm-stat-label">Soglia Critica Estrema</div>
                        <div class="pm-param-value" style="color:var(--pm-red)">
                            <?php echo e(\App\Services\AlertService::OCCUPANCY_DANGER_PCT); ?>%
                        </div>
                        <div class="pm-param-desc">
                            Rischio altissimo di overbooking. Azione immediata consigliata.
                        </div>
                    </div>
                    <div class="pm-param-card">
                        <div class="pm-stat-label">Orizzonte di Previsione</div>
                        <div class="pm-param-value" style="color:var(--pm-accent)">
                            <?php echo e(\App\Services\AlertService::DAYS_AHEAD_CHECK); ?> Giorni
                        </div>
                        <div class="pm-param-desc">
                            L'algoritmo analizza prenotazioni fino a 7 giorni nel futuro.
                        </div>
                    </div>
                    <div class="pm-param-card">
                        <div class="pm-stat-label">Traffico Cancellazioni</div>
                        <div class="pm-param-value" style="color:var(--pm-amber)">
                            <?php echo e(\App\Services\AlertService::CANCELLATION_THRESHOLD); ?>+
                        </div>
                        <div class="pm-param-desc">
                            Soglia limite di cancellazioni giornaliere prima di un alert.
                        </div>
                    </div>
                </div>
            </div>

        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\parking-manager\resources\views/alerts.blade.php ENDPATH**/ ?>