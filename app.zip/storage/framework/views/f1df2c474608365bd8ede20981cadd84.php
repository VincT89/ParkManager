<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title"><?php echo e($parkings->count() > 1 ? 'Dashboard Globale' : ($parkings->first()?->name ?? 'Parcheggio')); ?></div>
            <div class="pm-page-subtitle"><?php echo e(now()->isoFormat('dddd D MMMM YYYY')); ?></div>
        </div>
        <a href="<?php echo e(route('reservations.create')); ?>" class="pm-btn pm-btn-primary">
            Nuova prenotazione
        </a>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>



    
    <div class="pm-stats-grid pm-mb-16">
        <div class="pm-stat pm-animate-1">
            <div class="pm-stat-label">Occupazione oggi</div>
            <div class="pm-stat-value blue"><?php echo e($physicalOccupied + $allocatedSpots); ?> / <?php echo e($physicalTotal); ?></div>
            <div class="pm-stat-delta"><?php echo e($physicalPct); ?>% della capienza totale (include riservati)</div>
        </div>
        <div class="pm-stat pm-animate-2">
            <div class="pm-stat-label">Attive (settimana)</div>
            <div class="pm-stat-value green"><?php echo e($stats['week_count']); ?></div>
            <div class="pm-stat-delta">prenotazioni future attive</div>
        </div>
        <div class="pm-stat pm-animate-3">
            <div class="pm-stat-label">Questo mese</div>
            <div class="pm-stat-value amber"><?php echo e($stats['month_count']); ?></div>
            <div class="pm-stat-delta"><?php echo e(now()->format('M Y')); ?></div>
        </div>
        <div class="pm-stat pm-animate-4">
            <div class="pm-stat-label">Cancellate (mese)</div>
            <div class="pm-stat-value red"><?php echo e($stats['cancelled_month']); ?></div>
            <div class="pm-stat-delta">volume di no-show/disdette</div>
        </div>
    </div>

    

    <div class="pm-grid-2">

        <div class="pm-gap" style="height: 100%;">
            
            <div class="pm-card pm-animate-3" style="height: 100%; display: flex; flex-direction: column; justify-content: space-between;">
                <div class="pm-card-header">
                    <div class="pm-card-title">Prenotazioni attive</div>
                    <div class="pm-card-badge"><?php echo e(now()->format('d M')); ?></div>
                </div>
                <?php if($todayReservations->isEmpty()): ?>
                    <p class="pm-text-muted" style="font-size:13px">Nessuna prenotazione attiva oggi.</p>
                <?php else: ?>
                    <style>
                        .pm-table-scrollable th {
                            position: sticky;
                            top: 0;
                            background-color: white;
                            z-index: 10;
                            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
                        }
                    </style>
                    <div class="pm-table-wrapper pm-table-scrollable" style="flex: 1; overflow-y: auto;">
                        <table class="pm-table" style="margin-bottom: 0;">
                            <thead>
                                <tr>
                                    <th>Cliente</th>
                                    <th>Canale</th>
                                    <th>Arrivo</th>
                                    <th>Partenza</th>
                                    <th>Stato</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $todayReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="pm-td-main"><?php echo e($reservation->customer_name); ?></div>
                                            <?php if($reservation->customer_email): ?>
                                                <div class="pm-td-sub"><?php echo e($reservation->customer_email); ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="pm-platform">
                                                <div class="pm-dot blue"></div>
                                                <?php echo e($reservation->parkingListing->platform->name); ?>

                                            </div>
                                        </td>
                                        <td class="pm-mono"><?php echo e($reservation->starts_at->format('d-m H:i')); ?></td>
                                        <td class="pm-mono"><?php echo e($reservation->ends_at->format('d-m H:i')); ?></td>
                                        <td>
                                            <?php
                                                $statusColor = match ($reservation->status) {
                                                    \App\Enums\ReservationStatus::Confirmed => 'green',
                                                    \App\Enums\ReservationStatus::Cancelled => 'red',
                                                    \App\Enums\ReservationStatus::Pending => 'amber',
                                                    default => 'gray',
                                                };
                                            ?>
                                            <span class="pm-badge <?php echo e($statusColor); ?>">
                                                <?php echo e($reservation->status->label()); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php if($stats['today_count'] > 8): ?>
                            <tfoot>
                                <tr>
                                    <td colspan="5" style="text-align: center; padding: 4px 0 0 0; border-bottom: none;">
                                        <a href="<?php echo e(route('reservations.index', ['date_from' => now()->format('Y-m-d'), 'date_to' => now()->format('Y-m-d')])); ?>" class="pm-text-primary" style="text-decoration: none; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.05em; color: var(--pm-text-muted);">
                                            Vedi tutte le <?php echo e($stats['today_count']); ?> prenotazioni &rarr;
                                        </a>
                                    </td>
                                </tr>
                            </tfoot>
                            <?php endif; ?>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

        </div>

        
        <div class="pm-gap">
            <div class="pm-card pm-animate-2">
                <div class="pm-card-header">
                    <div class="pm-card-title">Azioni rapide</div>
                </div>
                <div class="pm-quick-actions">
                    <a href="<?php echo e(route('reservations.create')); ?>" class="pm-quick-action">
                        <div class="pm-quick-action-left">
                            <div class="pm-quick-action-icon blue">
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor"
                                    stroke-width="2">
                                    <line x1="7" y1="1" x2="7" y2="13" />
                                    <line x1="1" y1="7" x2="13" y2="7" />
                                </svg>
                            </div>
                            Nuova prenotazione
                        </div>
                        <span class="pm-quick-action-arrow">›</span>
                    </a>
                    <a href="<?php echo e(route('availability-blocks.create')); ?>" class="pm-quick-action">
                        <div class="pm-quick-action-left">
                            <div class="pm-quick-action-icon amber">
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor"
                                    stroke-width="2">
                                    <rect x="1" y="1" width="12" height="12" rx="2" />
                                    <line x1="7" y1="4" x2="7" y2="10" />
                                </svg>
                            </div>
                            Aggiungi blocco
                        </div>
                        <span class="pm-quick-action-arrow">›</span>
                    </a>
                    <a href="<?php echo e(route('reservations.index')); ?>" class="pm-quick-action">
                        <div class="pm-quick-action-left">
                            <div class="pm-quick-action-icon green">
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor"
                                    stroke-width="2">
                                    <rect x="1" y="3" width="12" height="9" rx="1" />
                                    <line x1="1" y1="6" x2="13" y2="6" />
                                </svg>
                            </div>
                            Tutte le prenotazioni
                        </div>
                        <span class="pm-quick-action-arrow">›</span>
                    </a>
                    <?php if(auth()->user()->isAdmin()): ?>
                        <a href="<?php echo e(route('platforms.index')); ?>" class="pm-quick-action">
                            <div class="pm-quick-action-left">
                                <div class="pm-quick-action-icon blue">
                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor"
                                        stroke-width="2">
                                        <circle cx="7" cy="7" r="5" />
                                        <line x1="7" y1="4" x2="7" y2="7" />
                                        <line x1="7" y1="7" x2="9" y2="9" />
                                    </svg>
                                </div>
                                Gestione piattaforme
                            </div>
                            <span class="pm-quick-action-arrow">›</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="pm-card pm-animate-3">
                <div class="pm-card-header">
                    <div class="pm-card-title">Impatto commerciale canali</div>
                    <div class="pm-card-badge">oggi</div>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $commercialPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="pm-channel-row" style="<?php echo e(!$loop->last ? 'margin-bottom: 12px; padding-bottom: 12px; border-bottom: 1px solid var(--pm-border-color);' : ''); ?>">
                        <div class="pm-channel-meta" style="margin-bottom: 6px;">
                            <div class="pm-channel-name"><?php echo e($channel['platform']); ?></div>
                            <div class="pm-channel-nums" style="font-size: 11px;">
                                <?php echo e($channel['sold_today']); ?> posti (<?php echo e($channel['impact_pct']); ?>%)
                            </div>
                        </div>
                        <div class="pm-progress-track">
                            <div class="pm-progress-fill green"
                                style="width: <?php echo e($channel['sold_today'] > 0 ? min(100, $channel['impact_pct']) : 0); ?>%">
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="pm-text-muted" style="font-size:13px">Nessun canale configurato.</p>
                <?php endif; ?>
            </div>
        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\SODANO\PARCHEGGIO\parking-manager\resources\views/dashboard.blade.php ENDPATH**/ ?>