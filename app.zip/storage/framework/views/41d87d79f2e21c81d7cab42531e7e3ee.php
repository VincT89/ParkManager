<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">Modifica piattaforma</div>
            <div class="pm-page-subtitle"><?php echo e($platform->name); ?></div>
        </div>
        <a href="<?php echo e(route('platforms.index')); ?>" class="pm-btn pm-btn-secondary">
            Torna alla lista
        </a>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>

    <div class="pm-card pm-animate" style="max-width:720px">
        <form method="POST" action="<?php echo e(route('platforms.update', $platform)); ?>" class="pm-form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="pm-form-grid-2">
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Nome</label>
                    <input type="text" name="name"
                           value="<?php echo e(old('name', $platform->name)); ?>"
                           required class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Slug</label>
                    <input type="text" name="slug"
                           value="<?php echo e(old('slug', $platform->slug)); ?>"
                           required class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label">Sito web</label>
                    <input type="url" name="website"
                           value="<?php echo e(old('website', $platform->website)); ?>"
                           class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label">Email contatto</label>
                    <input type="email" name="contact_email"
                           value="<?php echo e(old('contact_email', $platform->contact_email)); ?>"
                           class="pm-input" />
                </div>
            </div>

            <div class="pm-checkbox-group">
                <input type="checkbox" name="is_active" id="is_active" value="1"
                       <?php echo e(old('is_active', $platform->is_active) ? 'checked' : ''); ?>

                       class="pm-checkbox" />
                <label for="is_active" class="pm-checkbox-label">Piattaforma attiva</label>
            </div>

            <div class="pm-form-actions">
                <button type="submit" class="pm-btn pm-btn-primary">Salva modifiche</button>
                <a href="<?php echo e(route('platforms.index')); ?>" class="pm-btn pm-btn-secondary">Annulla</a>
            </div>

        </form>
    </div>

    
    <div class="pm-card pm-animate" style="max-width:720px;margin-top:24px">
        <div style="font-size:16px;font-weight:600;margin-bottom:16px;border-bottom:1px solid var(--pm-border);padding-bottom:12px;color:var(--pm-text);">
            Collega Parcheggio
        </div>
        <?php if($platform->listings->count() > 0): ?>
            <div style="margin-bottom: 24px;">
                <div style="font-size: 14px; font-weight: 500; margin-bottom: 8px; color: var(--pm-text-muted);">Parcheggi attualmente collegati:</div>
                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                    <?php $__currentLoopData = $platform->listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="pm-badge <?php echo e($listing->is_active ? 'green' : 'gray'); ?>"><?php echo e($listing->parking->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if($parkings->count() > 0): ?>
            <form method="POST" action="<?php echo e(route('platforms.attach', $platform)); ?>" class="pm-form">
                <?php echo csrf_field(); ?>
                
                <div class="pm-form-grid-2" style="align-items:end;">
                    <div class="pm-form-group" style="margin:0;">
                        <label class="pm-label pm-label-required">Collega Nuovo Parcheggio</label>
                        <select name="parking_id" required class="pm-select">
                            <option value="">Seleziona parcheggio...</option>
                            <?php $__currentLoopData = $parkings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($parking->id); ?>">
                                    <?php echo e($parking->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div style="margin:0;">
                        <button type="submit" class="pm-btn pm-btn-primary">Collega Canale</button>
                    </div>
                </div>
            </form>
        <?php else: ?>
            <div style="padding: 16px; background: #f8fafc; border: 1px solid var(--pm-border); border-radius: 8px; text-align: center; color: var(--pm-text-muted); font-size: 14px;">
                Tutti i parcheggi attivi sono già stati collegati a questa piattaforma.
            </div>
        <?php endif; ?>
    </div>

    
    <div class="pm-card pm-animate" style="max-width:720px;margin-top:24px">
        <div style="font-size:16px;font-weight:600;margin-bottom:16px;border-bottom:1px solid var(--pm-border);padding-bottom:12px;color:var(--pm-text);">
            Mapping Prodotti (Manuale)
        </div>
        
        <div class="mb-6">
            <?php if($mappings->count() > 0): ?>
                <div class="overflow-x-auto mb-4">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Codice Esterno</th>
                                <th scope="col" class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome (Opzionale)</th>
                                <th scope="col" class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prodotto Interno</th>
                                <th scope="col" class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Azioni</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $mappings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-4 py-2 text-sm font-medium text-gray-900"><?php echo e($mapping->external_ref); ?></td>
                                    <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($mapping->external_name ?? '-'); ?></td>
                                    <td class="px-4 py-2 text-sm text-gray-500">
                                        <?php echo e($mapping->parkingProduct->name ?? 'Prodotto rimosso'); ?>

                                        <div class="text-xs text-gray-400"><?php echo e($mapping->parkingProduct->parking->name ?? ''); ?></div>
                                    </td>
                                    <td class="px-4 py-2 text-sm text-right">
                                        <form method="POST" action="<?php echo e(route('platforms.mappings.destroy', $mapping)); ?>" onsubmit="return confirm('Sicuro di voler eliminare questo mapping?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 hover:text-red-900">Elimina</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-sm text-gray-500 mb-4">Nessun mapping configurato. Associa i codici prodotto della piattaforma ai prodotti del parcheggio.</p>
            <?php endif; ?>
        </div>

        <div style="font-size:14px;font-weight:600;margin-bottom:12px;color:var(--pm-text);">
            Aggiungi nuovo mapping
        </div>
        <form method="POST" action="<?php echo e(route('platforms.mappings.store', $platform)); ?>" class="pm-form">
            <?php echo csrf_field(); ?>
            
            <div class="pm-form-grid-2" style="align-items:end;">
                <div class="pm-form-group" style="margin:0;">
                    <label class="pm-label pm-label-required">Codice Esterno (Ref)</label>
                    <input type="text" name="external_ref" required class="pm-input" placeholder="es. STANDARD_1" />
                    <?php $__errorArgs = ['external_ref'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-500 text-xs mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="pm-form-group" style="margin:0;">
                    <label class="pm-label">Nome Esterno (Opzionale)</label>
                    <input type="text" name="external_name" class="pm-input" placeholder="es. Parcheggio Standard" />
                </div>
                <div class="pm-form-group" style="margin:0;">
                    <label class="pm-label pm-label-required">Prodotto Interno</label>
                    <select name="parking_product_id" required class="pm-select">
                        <option value="">Seleziona prodotto...</option>
                        <?php $__currentLoopData = $platform->listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($listing->parking): ?>
                                <optgroup label="<?php echo e($listing->parking->name); ?>">
                                    <?php $__currentLoopData = $listing->parking->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?> (Capacità: <?php echo e($product->capacity); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div style="margin:0;">
                    <button type="submit" class="pm-btn pm-btn-primary">Aggiungi Mapping</button>
                </div>
            </div>
        </form>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\SODANO\PARCHEGGIO\parking-manager\resources\views/platforms/edit.blade.php ENDPATH**/ ?>