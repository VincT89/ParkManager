<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">Piattaforme</div>
            <div class="pm-page-subtitle">gestione canali di vendita e Posti assegnati</div>
        </div>
        <a href="<?php echo e(route('platforms.create')); ?>" class="pm-btn pm-btn-primary">
            Nuova piattaforma
        </a>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>

    <div class="pm-gap">
        <?php $__empty_1 = true; $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="pm-card pm-animate">

                
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
                    <div style="display:flex;align-items:center;gap:12px">
                        <div style="display:flex;flex-direction:column;gap:2px">
                            <div style="display:flex;align-items:center;gap:10px">
                                <span style="font-size:15px;font-weight:600;color:var(--pm-text)">
                                    <?php echo e($platform->name); ?>

                                </span>
                                <span class="pm-badge <?php echo e($platform->is_active ? 'green' : 'red'); ?>">
                                    <?php echo e($platform->is_active ? 'Attiva' : 'Inattiva'); ?>

                                </span>
                            </div>
                            <div style="display:flex;align-items:center;gap:16px">
                                <span class="pm-text-muted pm-text-mono"><?php echo e($platform->slug); ?></span>
                                <?php if($platform->website): ?>
                                    <a href="<?php echo e($platform->website); ?>" target="_blank"
                                       style="font-size:12px;color:var(--pm-accent);text-decoration:none">
                                        <?php echo e($platform->website); ?>

                                    </a>
                                <?php endif; ?>
                                <?php if($platform->contact_email): ?>
                                    <span class="pm-text-muted" style="font-size:12px">
                                        <?php echo e($platform->contact_email); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div style="display:flex;gap:8px">
                        <a href="<?php echo e(route('platforms.edit', $platform)); ?>"
                           class="pm-btn pm-btn-secondary pm-btn-sm">
                            Modifica
                        </a>
                        <form method="POST"
                              action="<?php echo e(route('platforms.destroy', $platform)); ?>"
                              onsubmit="return confirm('Disattivare la piattaforma?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="pm-btn pm-btn-danger pm-btn-sm">
                                Disattiva
                            </button>
                        </form>
                    </div>
                </div>

                <div style="border-top:1px solid var(--pm-border);padding-top:16px;margin-top:16px;">
                    <div style="font-size:12px;font-weight:500;color:var(--pm-text-muted);
                                text-transform:uppercase;letter-spacing:0.08em;
                                font-family:var(--pm-mono);margin-bottom:12px">
                        Parcheggi Connessi
                    </div>
                    <?php if($platform->listings->isNotEmpty()): ?>
                        <div style="display:flex;flex-wrap:wrap;gap:8px;">
                            <?php $__currentLoopData = $platform->listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="pm-badge" style="background:rgba(255,255,255,0.05);color:var(--pm-text);border:1px solid var(--pm-border);">
                                    <?php echo e($listing->parking->name); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div style="font-size:13px;color:var(--pm-text-muted)">
                            Nessun parcheggio associato a questa piattaforma. Entra in Modifica per collegarne uno.
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="pm-card pm-animate">
                <p class="pm-text-muted" style="font-size:13px;text-align:center;padding:16px 0">
                    Nessuna piattaforma configurata.
                </p>
            </div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\parking-manager\resources\views/platforms/index.blade.php ENDPATH**/ ?>