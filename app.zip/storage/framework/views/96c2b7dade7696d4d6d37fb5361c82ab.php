<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">Nuova prenotazione</div>
            <div class="pm-page-subtitle">inserimento manuale</div>
        </div>
        <a href="<?php echo e(route('reservations.index')); ?>" class="pm-btn pm-btn-secondary">
            Torna alla lista
        </a>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>

    <div class="pm-card pm-animate" style="max-width:720px">
        <form method="POST" action="<?php echo e(route('reservations.store')); ?>" class="pm-form">
            <?php echo csrf_field(); ?>

            <div class="pm-form-grid-2">
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Canale / Piattaforma</label>
                    <select name="parking_listing_id" required class="pm-select">
                        <option value="">Seleziona canale...</option>
                        <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($listing->id); ?>"
                                <?php echo e(old('parking_listing_id') == $listing->id ? 'selected' : ''); ?>>
                                <?php echo e($listing->platform->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="pm-form-group">
                    <label class="pm-label">Categoria / Tipologia Posto</label>
                    <select name="parking_product_id" class="pm-select">
                        <option value="">Nessuna categoria (Legacy)</option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>"
                                <?php echo e(old('parking_product_id') == $product->id ? 'selected' : ''); ?>>
                                <?php echo e($product->name); ?> (€ <?php echo e(number_format($product->price, 2)); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="pm-form-grid-2">
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Nome cliente</label>
                    <input type="text" name="customer_name"
                           value="<?php echo e(old('customer_name')); ?>" required class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label">Email cliente</label>
                    <input type="email" name="customer_email"
                           value="<?php echo e(old('customer_email')); ?>" class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label">Telefono</label>
                    <input type="text" name="customer_phone"
                           value="<?php echo e(old('customer_phone')); ?>" class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label">Targa</label>
                    <input type="text" name="license_plate"
                           value="<?php echo e(old('license_plate')); ?>" class="pm-input" />
                </div>
            </div>

            <div class="pm-form-grid-2">
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Data arrivo</label>
                    <input type="datetime-local" name="starts_at"
                           value="<?php echo e(old('starts_at')); ?>" required class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Data partenza</label>
                    <input type="datetime-local" name="ends_at"
                           value="<?php echo e(old('ends_at')); ?>" required class="pm-input" />
                </div>
            </div>

            <div class="pm-form-grid-2">
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Posti</label>
                    <input type="number" name="spots" min="1"
                           value="<?php echo e(old('spots', 1)); ?>" required class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label">Prezzo (€)</label>
                    <input type="number" name="price" min="0" step="0.01"
                           value="<?php echo e(old('price')); ?>" class="pm-input" />
                </div>
            </div>

            <div class="pm-form-group">
                <label class="pm-label">Note</label>
                <textarea name="notes" class="pm-textarea"><?php echo e(old('notes')); ?></textarea>
            </div>

            <div class="pm-form-actions">
                <button type="submit" class="pm-btn pm-btn-primary">Crea prenotazione</button>
                <a href="<?php echo e(route('reservations.index')); ?>" class="pm-btn pm-btn-secondary">Annulla</a>
            </div>

        </form>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\SODANO\PARCHEGGIO\parking-manager\resources\views/reservations/create.blade.php ENDPATH**/ ?>