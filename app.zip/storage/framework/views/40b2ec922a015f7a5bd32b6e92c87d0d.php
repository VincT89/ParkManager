<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">Prenotazioni</div>
            <div class="pm-page-subtitle">gestione prenotazioni multi-canale</div>
        </div>
        <a href="<?php echo e(route('reservations.create')); ?>" class="pm-btn pm-btn-primary">
            Nuova prenotazione
        </a>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>

    <div class="pm-card pm-mb-16 pm-animate">
        <form method="GET" action="<?php echo e(route('reservations.index')); ?>" class="pm-filters">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                placeholder="Cerca cliente (premi Invio)..." class="pm-input" onchange="this.form.submit()" />
            <select name="platform_id" class="pm-select" onchange="this.form.submit()">
                <option value="">Tutti i canali</option>
                <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($platform->id); ?>" <?php echo e(request('platform_id') == $platform->id ? 'selected' : ''); ?>>
                        <?php echo e($platform->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="status" class="pm-select" onchange="this.form.submit()">
                <option value="">Tutti gli stati</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status->value); ?>" <?php echo e(request('status') == $status->value ? 'selected' : ''); ?>>
                        <?php echo e($status->label()); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select name="sort_by" class="pm-select" onchange="this.form.submit()">
                <option value="created_at_desc" <?php echo e(request('sort_by', 'created_at_desc') == 'created_at_desc' ? 'selected' : ''); ?>>Data Inserimento (Più recenti)</option>
                <option value="starts_at_asc" <?php echo e(request('sort_by') == 'starts_at_asc' ? 'selected' : ''); ?>>Data Arrivo (Crescente)</option>
                <option value="starts_at_desc" <?php echo e(request('sort_by') == 'starts_at_desc' ? 'selected' : ''); ?>>Data Arrivo (Decrescente)</option>
                <option value="created_at_asc" <?php echo e(request('sort_by') == 'created_at_asc' ? 'selected' : ''); ?>>Data Inserimento (Meno recenti)</option>
            </select>
            <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="pm-input"
                onchange="this.form.submit()" />
            <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="pm-input"
                onchange="this.form.submit()" />
            <a href="<?php echo e(route('reservations.index', array_merge(request()->except(['page', 'date_from', 'date_to']), [
                'quick_filter' => 'today',
            ]))); ?>" class="pm-btn <?php echo e(request('quick_filter') === 'today' ? 'pm-btn-primary' : 'pm-btn-secondary'); ?> pm-btn-sm">
                Oggi
            </a>
            <a href="<?php echo e(route('reservations.index')); ?>" class="pm-btn pm-btn-light pm-btn-sm">Reset</a>
            <a href="<?php echo e(route('reservations.export', request()->query())); ?>" class="pm-btn pm-btn-secondary pm-btn-sm">
                Esporta Excel
            </a>
        </form>
    </div>

    <div class="pm-card pm-animate-2">
        <div class="pm-table-wrapper">
            <table class="pm-table">
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>Volo</th>
                        <th>Canale</th>
                        <th>Arrivo</th>
                        <th>Partenza</th>
                        <th>Posti</th>
                        <th>Prezzo</th>
                        <th>Stato</th>
                        <th>Azioni</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="pm-td-main"><?php echo e($reservation->customer_name); ?></div>
                            </td>
                            <td>
                                <?php if($reservation->flight_reference): ?>
                                    <a href="https://www.flightradar24.com/data/flights/<?php echo e(strtolower($reservation->flight_reference)); ?>" target="_blank" style="font-family: var(--pm-mono); font-size: 11px; font-weight: 600; color: var(--pm-accent); text-decoration: none; background: rgba(249, 96, 32, 0.1); padding: 4px 8px; border-radius: 4px; border: 1px solid rgba(249, 96, 32, 0.2); display: inline-block;">
                                        <?php echo e($reservation->flight_reference); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="pm-text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="pm-platform">
                                    <div class="pm-dot blue"></div>
                                    <?php echo e($reservation->parkingListing->platform->name); ?>

                                </div>
                            </td>
                            <td class="pm-mono"><?php echo e($reservation->starts_at->format('d-m-Y H:i')); ?></td>
                            <td class="pm-mono"><?php echo e($reservation->ends_at->format('d-m-Y H:i')); ?></td>
                            <td class="pm-mono"><?php echo e($reservation->spots); ?></td>
                            <td class="pm-mono">
                                <?php echo e($reservation->price ? '€ ' . number_format($reservation->price * $reservation->spots, 2) : '—'); ?>

                            </td>
                            <td>
                                <?php
                                    $statusColor = match ($reservation->status) {
                                        \App\Enums\ReservationStatus::Confirmed => 'green',
                                        \App\Enums\ReservationStatus::Cancelled => 'red',
                                        \App\Enums\ReservationStatus::Pending => 'amber',
                                        default => 'gray',
                                    };
                                ?>
                                <span class="pm-badge <?php echo e($statusColor); ?>">
                                    <?php echo e($reservation->status->label()); ?>

                                </span>
                            </td>
                            <td>
                                <div style="display:flex;gap:8px;align-items:center">
                                    <a href="<?php echo e(route('reservations.show', $reservation)); ?>"
                                        class="pm-btn pm-btn-secondary pm-btn-sm" title="Vedi dettagli">
                                        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                                    </a>
                                    <a href="<?php echo e(route('reservations.edit', $reservation)); ?>"
                                        class="pm-btn pm-btn-secondary pm-btn-sm" title="Modifica">
                                        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                    </a>
                                    <?php if($reservation->status !== \App\Enums\ReservationStatus::Cancelled): ?>
                                        <form method="POST" action="<?php echo e(route('reservations.destroy', $reservation)); ?>"
                                            onsubmit="return confirm('Confermi la cancellazione?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="pm-btn pm-btn-danger pm-btn-sm" title="Cancella">
                                                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" style="text-align:center;padding:32px 0;color:var(--pm-text-muted)">
                                Nessuna prenotazione trovata.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($reservations->hasPages()): ?>
            <div class="pm-pagination">
                <?php echo e($reservations->links('vendor.pagination.pm')); ?>

            </div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\SODANO\PARCHEGGIO\parking-manager\resources\views/reservations/index.blade.php ENDPATH**/ ?>