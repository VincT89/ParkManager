<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">
                <?php echo e($type === 'entries' ? 'Macchine in entrata' : 'Macchine in uscita'); ?>

            </div>
            <div class="pm-page-subtitle">
                <?php echo e($date->format('d/m/Y')); ?>

            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div style="display:flex;gap:8px;margin-bottom:24px" class="pm-animate">
        <a href="<?php echo e(route('calendar', ['parking_id' => $parkingId])); ?>" class="pm-btn pm-btn-secondary">
            Vista calendario
        </a>
        <a href="<?php echo e(route('calendar.day', ['type' => 'entries', 'parking_id' => $parkingId, 'date' => $date->toDateString()])); ?>" class="pm-btn <?php echo e($type === 'entries' ? 'pm-btn-primary' : 'pm-btn-secondary'); ?>">
            Entrate
        </a>
        <a href="<?php echo e(route('calendar.day', ['type' => 'exits', 'parking_id' => $parkingId, 'date' => $date->toDateString()])); ?>" class="pm-btn <?php echo e($type === 'exits' ? 'pm-btn-primary' : 'pm-btn-secondary'); ?>">
            Uscite
        </a>
    </div>

    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--pm-border); padding-bottom:16px; margin-bottom:24px;" class="pm-animate">
        <div style="display:flex; align-items:baseline; gap:12px;">
            <div style="font-size:24px; font-weight:600; color:var(--pm-text); font-family:var(--pm-mono); line-height:1">
                <?php echo e($date->format('d / m')); ?>

            </div>
        </div>
        <div style="display:flex; gap:8px; align-items:center;">
            <a href="<?php echo e(route('calendar.day', ['type' => $type, 'parking_id' => $parkingId, 'date' => $date->copy()->subDay()->toDateString()])); ?>" class="pm-btn pm-btn-secondary pm-btn-sm">◄ Giorno prima</a>
            <a href="<?php echo e(route('calendar.day', ['type' => $type, 'parking_id' => $parkingId, 'date' => now()->toDateString()])); ?>" class="pm-btn pm-btn-secondary pm-btn-sm">Oggi</a>
            <a href="<?php echo e(route('calendar.day', ['type' => $type, 'parking_id' => $parkingId, 'date' => $date->copy()->addDay()->toDateString()])); ?>" class="pm-btn pm-btn-secondary pm-btn-sm">Giorno dopo ►</a>
            <a href="<?php echo e(route('calendar.day.export', ['type' => $type, 'parking_id' => $parkingId, 'date' => $date->toDateString()])); ?>" class="pm-btn pm-btn-secondary pm-btn-sm" style="margin-left: 16px;">Esporta Excel</a>
        </div>
    </div>

    <div class="pm-animate-2">
        <?php if($reservations->isEmpty()): ?>
            <div class="pm-card" style="padding: 32px; text-align: center; color: var(--pm-text-muted);">
                Nessuna macchina in <?php echo e($type === 'entries' ? 'entrata' : 'uscita'); ?> per questa data.
            </div>
        <?php else: ?>
            <div class="pm-card">
                <div class="pm-table-wrapper">
                    <table class="pm-table">
                    <thead>
                        <tr>
                            <th>Ora</th>
                            <th>Targa</th>
                            <th>Cliente</th>
                            <th>Telefono</th>
                            <th>Prodotto</th>
                            <th>Posti</th>
                            <th>Stato</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="pm-mono">
                                    <?php echo e($type === 'entries' ? $reservation->starts_at->format('H:i') : $reservation->ends_at->format('H:i')); ?>

                                </td>
                                <td>
                                    <?php if($reservation->license_plate): ?>
                                        <span style="font-family: var(--pm-mono); font-weight: 600; color: var(--pm-accent); background: rgba(249, 96, 32, 0.1); padding: 4px 8px; border-radius: 4px; border: 1px solid rgba(249, 96, 32, 0.2);">
                                            <?php echo e($reservation->license_plate); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="pm-text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="pm-td-main"><?php echo e($reservation->customer_name); ?></div>
                                </td>
                                <td>
                                    <?php if($reservation->customer_phone): ?>
                                        <a href="tel:<?php echo e($reservation->customer_phone); ?>" style="color: var(--pm-accent); text-decoration: none; font-weight: 500;">
                                            <?php echo e($reservation->customer_phone); ?>

                                        </a>
                                    <?php else: ?>
                                        <span class="pm-text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="pm-td-main"><?php echo e($reservation->parkingProduct->name ?? 'N/D'); ?></div>
                                    <div class="pm-td-sub"><?php echo e($reservation->parking->name ?? 'N/D'); ?></div>
                                </td>
                                <td class="pm-mono">
                                    <?php echo e($reservation->spots); ?>

                                </td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <input type="checkbox" id="check_<?php echo e($reservation->id); ?>" style="width: 18px; height: 18px; border-radius: 4px; border: 1px solid var(--pm-border); cursor: pointer;">
                                        <label for="check_<?php echo e($reservation->id); ?>" style="font-size: 13px; color: var(--pm-text-muted); cursor: pointer; user-select: none; margin: 0;">
                                            <?php echo e($reservation->parkingProduct->name ?? 'Veicolo'); ?> <?php echo e($type === 'entries' ? 'entrato' : 'uscito'); ?>

                                        </label>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\SODANO\PARCHEGGIO\parking-manager\resources\views/calendar/day.blade.php ENDPATH**/ ?>