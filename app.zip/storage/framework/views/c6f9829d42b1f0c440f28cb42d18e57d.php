<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">Nuovo blocco disponibilità</div>
            <div class="pm-page-subtitle">chiusura, manutenzione o blocco manuale</div>
        </div>
        <a href="<?php echo e(route('availability-blocks.index')); ?>" class="pm-btn pm-btn-secondary">
            Torna alla lista
        </a>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>

    <div class="pm-card pm-animate" style="max-width:720px">
        <form method="POST" action="<?php echo e(route('availability-blocks.store')); ?>" class="pm-form">
            <?php echo csrf_field(); ?>

            <div class="pm-form-grid-2">
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Parcheggio</label>
                    <select name="parking_id" required class="pm-select">
                        <option value="">Seleziona parcheggio...</option>
                        <?php $__currentLoopData = $parkings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($parking->id); ?>"
                                <?php echo e(old('parking_id') == $parking->id ? 'selected' : ''); ?>>
                                <?php echo e($parking->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="pm-form-group">
                    <label class="pm-label">
                        Canale specifico
                        <span class="pm-text-muted" style="font-weight:400;text-transform:none;letter-spacing:0">
                            (vuoto = tutti)
                        </span>
                    </label>
                    <select name="parking_listing_id" class="pm-select">
                        <option value="">Tutti i canali</option>
                        <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($listing->id); ?>"
                                <?php echo e(old('parking_listing_id') == $listing->id ? 'selected' : ''); ?>>
                                <?php echo e($listing->platform->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="pm-form-grid-2">
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Tipo blocco</label>
                    <select name="type" required class="pm-select">
                        <option value="">Seleziona tipo...</option>
                        <?php $__currentLoopData = $blockTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->value); ?>"
                                <?php echo e(old('type') == $type->value ? 'selected' : ''); ?>>
                                <?php echo e($type->label()); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Posti bloccati</label>
                    <input type="number" name="spots" min="1"
                           value="<?php echo e(old('spots', 1)); ?>" required class="pm-input" />
                </div>
            </div>

            <div class="pm-form-grid-2">
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Dal</label>
                    <input type="datetime-local" name="starts_at"
                           value="<?php echo e(old('starts_at')); ?>" required class="pm-input" />
                </div>
                <div class="pm-form-group">
                    <label class="pm-label pm-label-required">Al</label>
                    <input type="datetime-local" name="ends_at"
                           value="<?php echo e(old('ends_at')); ?>" required class="pm-input" />
                </div>
            </div>

            <div class="pm-form-group">
                <label class="pm-label">Motivo</label>
                <textarea name="reason" class="pm-textarea"
                          placeholder="Descrivi il motivo del blocco..."><?php echo e(old('reason')); ?></textarea>
            </div>

            <div class="pm-form-actions">
                <button type="submit" class="pm-btn pm-btn-primary">Crea blocco</button>
                <a href="<?php echo e(route('availability-blocks.index')); ?>" class="pm-btn pm-btn-secondary">Annulla</a>
            </div>

        </form>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\vince\OneDrive\Desktop\SODANO\PARCHEGGIO\parking-manager\resources\views/availability-blocks/create.blade.php ENDPATH**/ ?>