<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">Analisi redditività</div>
            <div class="pm-page-subtitle"><?php echo e($monthLabel); ?></div>
        </div>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginalbb0843bd48625210e6e530f88101357e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb0843bd48625210e6e530f88101357e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flash-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flash-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $attributes = $__attributesOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__attributesOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb0843bd48625210e6e530f88101357e)): ?>
<?php $component = $__componentOriginalbb0843bd48625210e6e530f88101357e; ?>
<?php unset($__componentOriginalbb0843bd48625210e6e530f88101357e); ?>
<?php endif; ?>

    
    <div class="pm-stats-grid pm-mb-16 pm-animate">
        <div class="pm-stat">
            <div class="pm-stat-label">Entrate mese</div>
            <div class="pm-stat-value green">€ <?php echo e(number_format($totals['revenue'], 2)); ?></div>
            <div class="pm-stat-delta">tutte le piattaforme</div>
        </div>
        <div class="pm-stat">
            <div class="pm-stat-label">Prenotazioni</div>
            <div class="pm-stat-value blue"><?php echo e($totals['count']); ?></div>
            <div class="pm-stat-delta">questo mese</div>
        </div>
        <div class="pm-stat">
            <div class="pm-stat-label">Prezzo medio</div>
            <div class="pm-stat-value amber">€ <?php echo e(number_format($totals['avg_price'], 2)); ?></div>
            <div class="pm-stat-delta">per prenotazione</div>
        </div>
        <div class="pm-stat">
            <div class="pm-stat-label">Cancellate</div>
            <div class="pm-stat-value red"><?php echo e($totals['cancelled']); ?></div>
            <div class="pm-stat-delta">questo mese</div>
        </div>
    </div>

    
    <div class="pm-gap">
        <?php $__currentLoopData = $channelStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="pm-card pm-animate-2">
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr;gap:24px;align-items:start">

                    
                    <div>
                        <div style="font-size:15px;font-weight:600;color:var(--pm-text);margin-bottom:4px">
                            <?php echo e($stat['platform']); ?>

                        </div>
                        <div class="pm-text-muted pm-text-mono" style="font-size:12px">
                            Piattaforma connessa
                        </div>
                    </div>

                    
                    <div>
                        <div class="pm-stat-label">Entrate</div>
                        <div
                            style="font-size:22px;font-weight:600;color:var(--pm-green);font-family:var(--pm-mono);letter-spacing:-0.02em">
                            € <?php echo e(number_format($stat['this_revenue'], 2)); ?>

                        </div>
                        <?php if($stat['revenue_change'] !== null): ?>
                            <div
                                style="font-size:12px;margin-top:4px;color:<?php echo e($stat['revenue_change'] >= 0 ? 'var(--pm-green)' : 'var(--pm-red)'); ?>">
                                <?php echo e($stat['revenue_change'] >= 0 ? '+' : ''); ?><?php echo e($stat['revenue_change']); ?>%
                                <span class="pm-text-muted">vs mese scorso</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div>
                        <div class="pm-stat-label">Prenotazioni</div>
                        <div
                            style="font-size:22px;font-weight:600;color:var(--pm-accent);font-family:var(--pm-mono);letter-spacing:-0.02em">
                            <?php echo e($stat['this_count']); ?>

                        </div>
                        <?php if($stat['count_change'] !== null): ?>
                            <div
                                style="font-size:12px;margin-top:4px;color:<?php echo e($stat['count_change'] >= 0 ? 'var(--pm-green)' : 'var(--pm-red)'); ?>">
                                <?php echo e($stat['count_change'] >= 0 ? '+' : ''); ?><?php echo e($stat['count_change']); ?>%
                                <span class="pm-text-muted">vs mese scorso</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div>
                        <div class="pm-stat-label">Prezzo medio</div>
                        <div
                            style="font-size:22px;font-weight:600;color:var(--pm-amber);font-family:var(--pm-mono);letter-spacing:-0.02em">
                            € <?php echo e(number_format($stat['avg_price'], 2)); ?>

                        </div>
                        <div style="font-size:12px;margin-top:4px" class="pm-text-muted">
                            <?php echo e($stat['cancelled']); ?> cancellate
                        </div>
                    </div>

                    
                    <div>
                        <div class="pm-stat-label" style="margin-bottom:8px">Trend 6 mesi</div>
                        <div style="display:flex;align-items:flex-end;gap:4px;height:40px">
                            <?php
                                $maxRevenue = max(array_column($stat['trend'], 'revenue')) ?: 1;
                            ?>
                            <?php $__currentLoopData = $stat['trend']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $height = $maxRevenue > 0 ? max(4, round(($t['revenue'] / $maxRevenue) * 40)) : 4;
                                    $isLast = $i === count($stat['trend']) - 1;
                                ?>
                                <div style="display:flex;flex-direction:column;align-items:center;gap:3px;flex:1">
                                    <div
                                        style="
                                        width:100%;
                                        height:<?php echo e($height); ?>px;
                                        background:<?php echo e($isLast ? 'var(--pm-accent)' : 'rgba(255,255,255,0.12)'); ?>;
                                        border-radius:2px;
                                        transition:height 0.3s;
                                    ">
                                    </div>
                                    <div style="font-size:9px;font-family:var(--pm-mono);color:var(--pm-text-dim)">
                                        <?php echo e($t['month']); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\parking-manager\resources\views/analytics.blade.php ENDPATH**/ ?>