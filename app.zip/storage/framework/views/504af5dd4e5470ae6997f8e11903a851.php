<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <div class="pm-page-title">Dettaglio prenotazione</div>
            <div class="pm-page-subtitle"><?php echo e($reservation->external_id); ?></div>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
            <a href="<?php echo e(route('reservations.index')); ?>" class="pm-btn pm-btn-secondary">
                Torna alla lista
            </a>
            <a href="<?php echo e(route('reservations.edit', $reservation)); ?>" class="pm-btn pm-btn-primary">
                Modifica
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="pm-card pm-animate" style="max-width:800px; padding: 32px;">
        
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; padding-bottom: 24px; border-bottom: 1px solid var(--pm-border-color);">
            <div>
                <h2 style="font-size: 20px; font-weight: 600; color: var(--pm-text); margin-bottom: 8px;"><?php echo e($reservation->customer_name); ?></h2>
                <?php if($reservation->customer_email): ?>
                    <div style="color: var(--pm-text-muted); font-size: 14px;"><?php echo e($reservation->customer_email); ?></div>
                <?php endif; ?>
                <?php if($reservation->customer_phone): ?>
                    <div style="color: var(--pm-text-muted); font-size: 14px;"><?php echo e($reservation->customer_phone); ?></div>
                <?php endif; ?>
            </div>
            <div style="text-align: right;">
                <?php
                    $statusColor = match ($reservation->status) {
                        \App\Enums\ReservationStatus::Confirmed => 'green',
                        \App\Enums\ReservationStatus::Cancelled => 'red',
                        \App\Enums\ReservationStatus::Pending => 'amber',
                        default => 'gray',
                    };
                ?>
                <span class="pm-badge <?php echo e($statusColor); ?>" style="font-size: 14px; padding: 6px 12px; margin-bottom: 12px; display: inline-block;">
                    <?php echo e($reservation->status->label()); ?>

                </span>
                <div style="font-family: var(--pm-mono); font-size: 13px; color: var(--pm-text-muted);">
                    Inserita il <?php echo e($reservation->created_at->format('d/m/Y H:i')); ?>

                </div>
            </div>
        </div>

        <div class="pm-form-grid-2" style="margin-bottom: 32px;">
            <div>
                <div class="pm-label">Canale di vendita</div>
                <div style="font-weight: 500; font-size: 15px; color: var(--pm-text);">
                    <div class="pm-platform" style="display: inline-flex;">
                        <div class="pm-dot blue"></div>
                        <?php echo e($reservation->parkingListing?->platform?->name ?? 'N/A'); ?>

                    </div>
                </div>
            </div>
            <div>
                <div class="pm-label">Categoria / Tipologia Posto</div>
                <div style="font-weight: 500; font-size: 15px; color: var(--pm-text);">
                    <?php echo e($reservation->parkingProduct?->name ?? 'Nessuna categoria'); ?>

                </div>
            </div>
        </div>

        <div class="pm-form-grid-2" style="margin-bottom: 32px; background: var(--pm-bg-soft); padding: 16px; border-radius: 8px; border: 1px solid var(--pm-border-color);">
            <div>
                <div class="pm-label">Arrivo previsto</div>
                <div style="font-weight: 600; font-size: 16px; color: var(--pm-text);">
                    <?php echo e($reservation->starts_at->format('d/m/Y')); ?> <span style="color: var(--pm-text-muted);">alle</span> <?php echo e($reservation->starts_at->format('H:i')); ?>

                </div>
            </div>
            <div>
                <div class="pm-label">Partenza prevista</div>
                <div style="font-weight: 600; font-size: 16px; color: var(--pm-text);">
                    <?php echo e($reservation->ends_at->format('d/m/Y')); ?> <span style="color: var(--pm-text-muted);">alle</span> <?php echo e($reservation->ends_at->format('H:i')); ?>

                </div>
            </div>
        </div>

        <div class="pm-form-grid-3" style="margin-bottom: 32px;">
            <div>
                <div class="pm-label">Veicolo / Targa</div>
                <?php if($reservation->license_plate): ?>
                    <div style="font-family: var(--pm-mono); font-weight: 600; font-size: 15px; color: var(--pm-text); background: var(--pm-bg-soft); padding: 4px 8px; border-radius: 4px; border: 1px solid var(--pm-border-color); display: inline-block;">
                        <?php echo e($reservation->license_plate); ?>

                    </div>
                <?php else: ?>
                    <span class="pm-text-muted">-</span>
                <?php endif; ?>
            </div>
            <div>
                <div class="pm-label">Riferimento Volo</div>
                <?php if($reservation->flight_reference): ?>
                    <a href="https://www.flightradar24.com/data/flights/<?php echo e(strtolower($reservation->flight_reference)); ?>" target="_blank" style="font-family: var(--pm-mono); font-size: 15px; font-weight: 600; color: var(--pm-accent); text-decoration: none; background: rgba(249, 96, 32, 0.1); padding: 4px 8px; border-radius: 4px; border: 1px solid rgba(249, 96, 32, 0.2); display: inline-block;">
                        <?php echo e($reservation->flight_reference); ?>

                    </a>
                <?php else: ?>
                    <span class="pm-text-muted">-</span>
                <?php endif; ?>
            </div>
            <div>
                <div class="pm-label">Posti occupati</div>
                <div style="font-weight: 600; font-size: 18px; color: var(--pm-text);">
                    <?php echo e($reservation->spots); ?>

                </div>
            </div>
        </div>

        <div class="pm-form-grid-2" style="margin-bottom: 32px;">
            <div>
                <div class="pm-label">Prezzo Unitario</div>
                <div style="font-weight: 500; font-size: 15px; color: var(--pm-text);">
                    € <?php echo e(number_format($reservation->price, 2)); ?>

                </div>
            </div>
            <div>
                <div class="pm-label">Totale Pratica</div>
                <div style="font-weight: 700; font-size: 20px; color: var(--pm-green);">
                    € <?php echo e(number_format($reservation->price * $reservation->spots, 2)); ?>

                </div>
            </div>
        </div>

        <?php if($reservation->notes): ?>
            <div style="margin-top: 32px; padding-top: 24px; border-top: 1px solid var(--pm-border-color);">
                <div class="pm-label">Note Operative</div>
                <div style="background: #fffbea; border: 1px solid #fef08a; padding: 16px; border-radius: 8px; color: #854d0e; font-size: 14px; line-height: 1.5; white-space: pre-wrap;"><?php echo e($reservation->notes); ?></div>
            </div>
        <?php endif; ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\vince\OneDrive\Desktop\SODANO\PARCHEGGIO\parking-manager\resources\views/reservations/show.blade.php ENDPATH**/ ?>