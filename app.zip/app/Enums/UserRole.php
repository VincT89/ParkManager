<?php

namespace App\Enums;

enum UserRole: string
{
    case Admin = 'admin';
    case Staff = 'staff';

    public function label(): string
    {
      return match($this) {
        self::Admin => 'Admin',
        self::Staff => 'Staff',
      };
    }

    public function isAdmin(): bool
    {
        return $this === UserRole::Admin;
    }
}